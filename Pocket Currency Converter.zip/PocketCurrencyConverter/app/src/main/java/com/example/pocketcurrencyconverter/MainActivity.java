package com.example.pocketcurrencyconverter;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner;
    private Button convert;
    private EditText input;
    private TextView result1, result2, result3, result4;
    private double inputvalue;
    private int index;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        convert = findViewById(R.id.convert);
        input = findViewById(R.id.input);
        result1 = findViewById(R.id.result1);
        result2 = findViewById(R.id.result2);
        result3 = findViewById(R.id.result3);
        result4 = findViewById(R.id.result4);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
        index = position;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    convert.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            result1.setText("wait...");
            result2.setText("wait...");
            result3.setText("wait...");
            result4.setText("wait...");

            if (input.getText().toString().trim().length()> 0 && !input.getText().toString().trim().equals("."));
            String TextValue = input.getText().toString();
            inputvalue=Double.parseDouble(TextValue);

            new calculate().execuate();

        }

    }
    public class calculate extends AsyncTask<String, String, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            if (index = 0) {
                String uRl;
                try {
                    uRl = getJson("https://api.exchangeratesapi.io/latest");

                }
            }
        }
    public String getJson(String url) throws ClientProtocolException, IOException{

        StringBuilder build = new StringBuilder();
        HttpClient client = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        HttpResponse response = client.execute(httpGet);
        HttpEntity entity = response.getEntity();
        InputStream content = entity.getContent();
        BufferedReader reader = new BufferedReader(new InputStreamReader(content));
        String con;
        while ((con = reader.readLine()) != null) {
            build.append(con);
        }
        return build.toString();
    }
    }
}


